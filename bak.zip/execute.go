package main

//数据包结构(数据交换)
type Execute struct {
	Cmd  string            //set,get等操作命令
	Data map[string]string //数据
}
